live page of my calculator
https://magesh-agira.github.io/calculator/
